/**
 * Spanning tree and spanner algorithms.
 */
package org.jgrapht.alg.spanning;
