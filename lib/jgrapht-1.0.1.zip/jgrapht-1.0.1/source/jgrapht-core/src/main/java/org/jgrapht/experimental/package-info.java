/**
 * Experimental work or work-in-progress.
 * 
 * <p>
 * Not yet ready to be included in a release. It may contain classes that are: incomplete, not yet
 * documented, have not yet reached a satisfying form, etc.
 * 
 * <p>
 * The only requirement for classes included here is to compile.
 */
package org.jgrapht.experimental;
