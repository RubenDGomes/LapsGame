/**
 * Shortest-path related algorithms.
 */
package org.jgrapht.alg.shortestpath;
