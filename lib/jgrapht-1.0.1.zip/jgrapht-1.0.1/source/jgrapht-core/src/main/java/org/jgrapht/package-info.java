/**
 * The front-end API's interfaces and classes, including {@link org.jgrapht.Graph},
 * {@link org.jgrapht.DirectedGraph} and {@link org.jgrapht.UndirectedGraph}.
 */
package org.jgrapht;
